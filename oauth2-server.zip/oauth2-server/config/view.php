<?php

return [
	'paths' => [
		__DIR__ . '/../resources/views'
	],
	'compiled' => __DIR__ . '/../storage/cache',
];