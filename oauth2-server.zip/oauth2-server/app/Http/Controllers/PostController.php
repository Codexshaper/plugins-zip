<?php

namespace WPB\App\Http\Controllers;

use WPB\App\Post;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Routing\Controller;

class PostController extends Controller
{}