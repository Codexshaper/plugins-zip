const mixin = {
  data: () => ({
    token: {
      csrf: null
    }
  }),
  computed: {
  },
  created() {
  },
  methods: {
    
  }
};

export default mixin;