<?php

use Codexshaper_Oauth_Server\Support\Facades\Route;
use Illuminate\Http\Request;
use CodexShaper\OAuth2\Server\Manager;

/**
 * You can use either $router object or Route facate to create new route
 */

Route::prefix('cos')->group(function(){
	Route::group(['prefix' => 'oauth', 'namespace' => '\CodexShaper\OAuth2\Server\Http\Controllers'], function () {
	    Route::post('token', 'ClientController@issueAccessToken');
	    Route::get('authorize', 'AuthorizationController@authorize');

	    Route::group(['middleware' => ['web', 'auth']], function () {
	        Route::get('clients', 'ClientController@all');
	        Route::post('clients', 'ClientController@store');
	        Route::put('clients', 'ClientController@update');
	        Route::delete('clients', 'ClientController@destroy');

	        // Refresh token
	        Route::post('token/refresh', 'ClientController@issueAccessToken');
	    });
	});
});