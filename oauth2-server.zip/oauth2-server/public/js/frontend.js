(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["frontend"],{

/***/ "./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/App.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/frontend/App.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n/* harmony default export */ __webpack_exports__[\"default\"] = ({\n  name: 'App'\n});\n\n//# sourceURL=webpack:///./resources/js/frontend/App.vue?./node_modules/babel-loader/lib!./node_modules/vue-loader/lib??vue-loader-options");

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/pages/Home.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/frontend/pages/Home.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n//\n//\n//\n//\n//\n//\n/* harmony default export */ __webpack_exports__[\"default\"] = ({\n  name: 'Home',\n\n  data() {\n    return {\n      msg: 'Welcome to Your Vue.js Frontend App'\n    };\n  }\n\n});\n\n//# sourceURL=webpack:///./resources/js/frontend/pages/Home.vue?./node_modules/babel-loader/lib!./node_modules/vue-loader/lib??vue-loader-options");

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/pages/Profile.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/frontend/pages/Profile.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n//\n//\n//\n//\n//\n//\n/* harmony default export */ __webpack_exports__[\"default\"] = ({\n  name: 'Profile',\n\n  data() {\n    return {};\n  }\n\n});\n\n//# sourceURL=webpack:///./resources/js/frontend/pages/Profile.vue?./node_modules/babel-loader/lib!./node_modules/vue-loader/lib??vue-loader-options");

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/App.vue?vue&type=template&id=57c90a02&":
/*!****************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/frontend/App.vue?vue&type=template&id=57c90a02& ***!
  \****************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"render\", function() { return render; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"staticRenderFns\", function() { return staticRenderFns; });\nvar render = function() {\n  var _vm = this\n  var _h = _vm.$createElement\n  var _c = _vm._self._c || _h\n  return _c(\n    \"div\",\n    { attrs: { id: \"vue-frontend-app\" } },\n    [\n      _c(\"h2\", [_vm._v(\"Frontend App\")]),\n      _vm._v(\" \"),\n      _c(\"router-link\", { attrs: { to: \"/\" } }, [_vm._v(\"Home\")]),\n      _vm._v(\" \"),\n      _c(\"router-link\", { attrs: { to: \"/profile\" } }, [_vm._v(\"Profile\")]),\n      _vm._v(\" \"),\n      _c(\"router-view\")\n    ],\n    1\n  )\n}\nvar staticRenderFns = []\nrender._withStripped = true\n\n\n\n//# sourceURL=webpack:///./resources/js/frontend/App.vue?./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options");

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/pages/Home.vue?vue&type=template&id=58ed6bf9&scoped=true&":
/*!***********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/frontend/pages/Home.vue?vue&type=template&id=58ed6bf9&scoped=true& ***!
  \***********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"render\", function() { return render; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"staticRenderFns\", function() { return staticRenderFns; });\nvar render = function() {\n  var _vm = this\n  var _h = _vm.$createElement\n  var _c = _vm._self._c || _h\n  return _c(\"div\", { staticClass: \"hello\" }, [\n    _c(\"span\", [_vm._v(_vm._s(_vm.msg))])\n  ])\n}\nvar staticRenderFns = []\nrender._withStripped = true\n\n\n\n//# sourceURL=webpack:///./resources/js/frontend/pages/Home.vue?./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options");

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/pages/Profile.vue?vue&type=template&id=6f0b4702&scoped=true&":
/*!**************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/frontend/pages/Profile.vue?vue&type=template&id=6f0b4702&scoped=true& ***!
  \**************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"render\", function() { return render; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"staticRenderFns\", function() { return staticRenderFns; });\nvar render = function() {\n  var _vm = this\n  var _h = _vm.$createElement\n  var _c = _vm._self._c || _h\n  return _c(\"div\", { staticClass: \"profile\" }, [\n    _vm._v(\"\\n  The Profile Page\\n\")\n  ])\n}\nvar staticRenderFns = []\nrender._withStripped = true\n\n\n\n//# sourceURL=webpack:///./resources/js/frontend/pages/Profile.vue?./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options");

/***/ }),

/***/ "./resources/js/frontend/App.vue":
/*!***************************************!*\
  !*** ./resources/js/frontend/App.vue ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _App_vue_vue_type_template_id_57c90a02___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./App.vue?vue&type=template&id=57c90a02& */ \"./resources/js/frontend/App.vue?vue&type=template&id=57c90a02&\");\n/* harmony import */ var _App_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./App.vue?vue&type=script&lang=js& */ \"./resources/js/frontend/App.vue?vue&type=script&lang=js&\");\n/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ \"./node_modules/vue-loader/lib/runtime/componentNormalizer.js\");\n\n\n\n\n\n/* normalize component */\n\nvar component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__[\"default\"])(\n  _App_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[\"default\"],\n  _App_vue_vue_type_template_id_57c90a02___WEBPACK_IMPORTED_MODULE_0__[\"render\"],\n  _App_vue_vue_type_template_id_57c90a02___WEBPACK_IMPORTED_MODULE_0__[\"staticRenderFns\"],\n  false,\n  null,\n  null,\n  null\n  \n)\n\n/* hot reload */\nif (false) { var api; }\ncomponent.options.__file = \"resources/js/frontend/App.vue\"\n/* harmony default export */ __webpack_exports__[\"default\"] = (component.exports);\n\n//# sourceURL=webpack:///./resources/js/frontend/App.vue?");

/***/ }),

/***/ "./resources/js/frontend/App.vue?vue&type=script&lang=js&":
/*!****************************************************************!*\
  !*** ./resources/js/frontend/App.vue?vue&type=script&lang=js& ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib??vue-loader-options!./App.vue?vue&type=script&lang=js& */ \"./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/App.vue?vue&type=script&lang=js&\");\n/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__[\"default\"] = (_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[\"default\"]); \n\n//# sourceURL=webpack:///./resources/js/frontend/App.vue?");

/***/ }),

/***/ "./resources/js/frontend/App.vue?vue&type=template&id=57c90a02&":
/*!**********************************************************************!*\
  !*** ./resources/js/frontend/App.vue?vue&type=template&id=57c90a02& ***!
  \**********************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_template_id_57c90a02___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib??vue-loader-options!./App.vue?vue&type=template&id=57c90a02& */ \"./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/App.vue?vue&type=template&id=57c90a02&\");\n/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, \"render\", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_template_id_57c90a02___WEBPACK_IMPORTED_MODULE_0__[\"render\"]; });\n\n/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, \"staticRenderFns\", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_template_id_57c90a02___WEBPACK_IMPORTED_MODULE_0__[\"staticRenderFns\"]; });\n\n\n\n//# sourceURL=webpack:///./resources/js/frontend/App.vue?");

/***/ }),

/***/ "./resources/js/frontend/main.js":
/*!***************************************!*\
  !*** ./resources/js/frontend/main.js ***!
  \***************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ \"./node_modules/vue/dist/vue.esm.js\");\n/* harmony import */ var _App_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./App.vue */ \"./resources/js/frontend/App.vue\");\n/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./store */ \"./resources/js/frontend/store/index.js\");\n/* harmony import */ var _router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./router */ \"./resources/js/frontend/router/index.js\");\n\n\n\n\nwindow.toastr = __webpack_require__(/*! toastr */ \"./node_modules/toastr/toastr.js\");\nvue__WEBPACK_IMPORTED_MODULE_0__[\"default\"].config.productionTip = false;\n/* eslint-disable no-new */\n\nnew vue__WEBPACK_IMPORTED_MODULE_0__[\"default\"]({\n  el: '#vue-frontend-app',\n  store: _store__WEBPACK_IMPORTED_MODULE_2__[\"default\"],\n  router: _router__WEBPACK_IMPORTED_MODULE_3__[\"default\"],\n  render: h => h(_App_vue__WEBPACK_IMPORTED_MODULE_1__[\"default\"])\n});\n\n//# sourceURL=webpack:///./resources/js/frontend/main.js?");

/***/ }),

/***/ "./resources/js/frontend/pages/Home.vue":
/*!**********************************************!*\
  !*** ./resources/js/frontend/pages/Home.vue ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _Home_vue_vue_type_template_id_58ed6bf9_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Home.vue?vue&type=template&id=58ed6bf9&scoped=true& */ \"./resources/js/frontend/pages/Home.vue?vue&type=template&id=58ed6bf9&scoped=true&\");\n/* harmony import */ var _Home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Home.vue?vue&type=script&lang=js& */ \"./resources/js/frontend/pages/Home.vue?vue&type=script&lang=js&\");\n/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ \"./node_modules/vue-loader/lib/runtime/componentNormalizer.js\");\n\n\n\n\n\n/* normalize component */\n\nvar component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__[\"default\"])(\n  _Home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[\"default\"],\n  _Home_vue_vue_type_template_id_58ed6bf9_scoped_true___WEBPACK_IMPORTED_MODULE_0__[\"render\"],\n  _Home_vue_vue_type_template_id_58ed6bf9_scoped_true___WEBPACK_IMPORTED_MODULE_0__[\"staticRenderFns\"],\n  false,\n  null,\n  \"58ed6bf9\",\n  null\n  \n)\n\n/* hot reload */\nif (false) { var api; }\ncomponent.options.__file = \"resources/js/frontend/pages/Home.vue\"\n/* harmony default export */ __webpack_exports__[\"default\"] = (component.exports);\n\n//# sourceURL=webpack:///./resources/js/frontend/pages/Home.vue?");

/***/ }),

/***/ "./resources/js/frontend/pages/Home.vue?vue&type=script&lang=js&":
/*!***********************************************************************!*\
  !*** ./resources/js/frontend/pages/Home.vue?vue&type=script&lang=js& ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib??vue-loader-options!./Home.vue?vue&type=script&lang=js& */ \"./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/pages/Home.vue?vue&type=script&lang=js&\");\n/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__[\"default\"] = (_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[\"default\"]); \n\n//# sourceURL=webpack:///./resources/js/frontend/pages/Home.vue?");

/***/ }),

/***/ "./resources/js/frontend/pages/Home.vue?vue&type=template&id=58ed6bf9&scoped=true&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/frontend/pages/Home.vue?vue&type=template&id=58ed6bf9&scoped=true& ***!
  \*****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_template_id_58ed6bf9_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Home.vue?vue&type=template&id=58ed6bf9&scoped=true& */ \"./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/pages/Home.vue?vue&type=template&id=58ed6bf9&scoped=true&\");\n/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, \"render\", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_template_id_58ed6bf9_scoped_true___WEBPACK_IMPORTED_MODULE_0__[\"render\"]; });\n\n/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, \"staticRenderFns\", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_template_id_58ed6bf9_scoped_true___WEBPACK_IMPORTED_MODULE_0__[\"staticRenderFns\"]; });\n\n\n\n//# sourceURL=webpack:///./resources/js/frontend/pages/Home.vue?");

/***/ }),

/***/ "./resources/js/frontend/pages/Profile.vue":
/*!*************************************************!*\
  !*** ./resources/js/frontend/pages/Profile.vue ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _Profile_vue_vue_type_template_id_6f0b4702_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Profile.vue?vue&type=template&id=6f0b4702&scoped=true& */ \"./resources/js/frontend/pages/Profile.vue?vue&type=template&id=6f0b4702&scoped=true&\");\n/* harmony import */ var _Profile_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Profile.vue?vue&type=script&lang=js& */ \"./resources/js/frontend/pages/Profile.vue?vue&type=script&lang=js&\");\n/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ \"./node_modules/vue-loader/lib/runtime/componentNormalizer.js\");\n\n\n\n\n\n/* normalize component */\n\nvar component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__[\"default\"])(\n  _Profile_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[\"default\"],\n  _Profile_vue_vue_type_template_id_6f0b4702_scoped_true___WEBPACK_IMPORTED_MODULE_0__[\"render\"],\n  _Profile_vue_vue_type_template_id_6f0b4702_scoped_true___WEBPACK_IMPORTED_MODULE_0__[\"staticRenderFns\"],\n  false,\n  null,\n  \"6f0b4702\",\n  null\n  \n)\n\n/* hot reload */\nif (false) { var api; }\ncomponent.options.__file = \"resources/js/frontend/pages/Profile.vue\"\n/* harmony default export */ __webpack_exports__[\"default\"] = (component.exports);\n\n//# sourceURL=webpack:///./resources/js/frontend/pages/Profile.vue?");

/***/ }),

/***/ "./resources/js/frontend/pages/Profile.vue?vue&type=script&lang=js&":
/*!**************************************************************************!*\
  !*** ./resources/js/frontend/pages/Profile.vue?vue&type=script&lang=js& ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Profile_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib??vue-loader-options!./Profile.vue?vue&type=script&lang=js& */ \"./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/pages/Profile.vue?vue&type=script&lang=js&\");\n/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__[\"default\"] = (_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Profile_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[\"default\"]); \n\n//# sourceURL=webpack:///./resources/js/frontend/pages/Profile.vue?");

/***/ }),

/***/ "./resources/js/frontend/pages/Profile.vue?vue&type=template&id=6f0b4702&scoped=true&":
/*!********************************************************************************************!*\
  !*** ./resources/js/frontend/pages/Profile.vue?vue&type=template&id=6f0b4702&scoped=true& ***!
  \********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Profile_vue_vue_type_template_id_6f0b4702_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Profile.vue?vue&type=template&id=6f0b4702&scoped=true& */ \"./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/frontend/pages/Profile.vue?vue&type=template&id=6f0b4702&scoped=true&\");\n/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, \"render\", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Profile_vue_vue_type_template_id_6f0b4702_scoped_true___WEBPACK_IMPORTED_MODULE_0__[\"render\"]; });\n\n/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, \"staticRenderFns\", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Profile_vue_vue_type_template_id_6f0b4702_scoped_true___WEBPACK_IMPORTED_MODULE_0__[\"staticRenderFns\"]; });\n\n\n\n//# sourceURL=webpack:///./resources/js/frontend/pages/Profile.vue?");

/***/ }),

/***/ "./resources/js/frontend/router/index.js":
/*!***********************************************!*\
  !*** ./resources/js/frontend/router/index.js ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ \"./node_modules/vue/dist/vue.esm.js\");\n/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-router */ \"./node_modules/vue-router/dist/vue-router.esm.js\");\n/* harmony import */ var _pages_Home_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../pages/Home.vue */ \"./resources/js/frontend/pages/Home.vue\");\n/* harmony import */ var _pages_Profile_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../pages/Profile.vue */ \"./resources/js/frontend/pages/Profile.vue\");\n\n\n\n\nvue__WEBPACK_IMPORTED_MODULE_0__[\"default\"].use(vue_router__WEBPACK_IMPORTED_MODULE_1__[\"default\"]);\n/* harmony default export */ __webpack_exports__[\"default\"] = (new vue_router__WEBPACK_IMPORTED_MODULE_1__[\"default\"]({\n  routes: [{\n    path: '/',\n    name: 'Home',\n    component: _pages_Home_vue__WEBPACK_IMPORTED_MODULE_2__[\"default\"]\n  }, {\n    path: '/profile',\n    name: 'Profile',\n    component: _pages_Profile_vue__WEBPACK_IMPORTED_MODULE_3__[\"default\"]\n  }]\n}));\n\n//# sourceURL=webpack:///./resources/js/frontend/router/index.js?");

/***/ }),

/***/ "./resources/js/frontend/store/index.js":
/*!**********************************************!*\
  !*** ./resources/js/frontend/store/index.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ \"./node_modules/vue/dist/vue.esm.js\");\n/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ \"./node_modules/vuex/dist/vuex.esm.js\");\n\n\nvue__WEBPACK_IMPORTED_MODULE_0__[\"default\"].use(vuex__WEBPACK_IMPORTED_MODULE_1__[\"default\"]); // Load store modules dynamically.\n\nconst requireContext = __webpack_require__(\"./resources/js/frontend/store/modules sync .*\\\\.js$\");\n\nconst modules = requireContext.keys().map(file => [file.replace(/(^.\\/)|(\\.js$)/g, ''), requireContext(file)]).reduce((modules, [name, module]) => {\n  if (module.namespaced === undefined) {\n    module.namespaced = true;\n  }\n\n  return { ...modules,\n    [name]: module\n  };\n}, {});\n/* harmony default export */ __webpack_exports__[\"default\"] = (new vuex__WEBPACK_IMPORTED_MODULE_1__[\"default\"].Store({\n  modules\n}));\n\n//# sourceURL=webpack:///./resources/js/frontend/store/index.js?");

/***/ }),

/***/ "./resources/js/frontend/store/modules sync .*\\.js$":
/*!***********************************************************************!*\
  !*** ./resources/js/frontend/store/modules sync nonrecursive .*\.js$ ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("var map = {\n\t\"./auth.js\": \"./resources/js/frontend/store/modules/auth.js\",\n\t\"./lang.js\": \"./resources/js/frontend/store/modules/lang.js\",\n\t\"./upload.js\": \"./resources/js/frontend/store/modules/upload.js\"\n};\n\n\nfunction webpackContext(req) {\n\tvar id = webpackContextResolve(req);\n\treturn __webpack_require__(id);\n}\nfunction webpackContextResolve(req) {\n\tif(!__webpack_require__.o(map, req)) {\n\t\tvar e = new Error(\"Cannot find module '\" + req + \"'\");\n\t\te.code = 'MODULE_NOT_FOUND';\n\t\tthrow e;\n\t}\n\treturn map[req];\n}\nwebpackContext.keys = function webpackContextKeys() {\n\treturn Object.keys(map);\n};\nwebpackContext.resolve = webpackContextResolve;\nmodule.exports = webpackContext;\nwebpackContext.id = \"./resources/js/frontend/store/modules sync .*\\\\.js$\";\n\n//# sourceURL=webpack:///./resources/js/frontend/store/modules_sync_nonrecursive_.*\\.js$?");

/***/ }),

/***/ "./resources/js/frontend/store/modules/auth.js":
/*!*****************************************************!*\
  !*** ./resources/js/frontend/store/modules/auth.js ***!
  \*****************************************************/
/*! exports provided: state, getters, mutations, actions */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"state\", function() { return state; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"getters\", function() { return getters; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"mutations\", function() { return mutations; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"actions\", function() { return actions; });\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ \"./node_modules/axios/index.js\");\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! js-cookie */ \"./node_modules/js-cookie/src/js.cookie.js\");\n/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(js_cookie__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _mutation_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../mutation-types */ \"./resources/js/frontend/store/mutation-types.js\");\n\n\n // state\n\nconst state = {\n  user: null,\n  token: js_cookie__WEBPACK_IMPORTED_MODULE_1___default.a.get('token')\n}; // getters\n\nconst getters = {\n  user: state => state.user,\n  token: state => state.token,\n  check: state => state.user !== null\n}; // mutations\n\nconst mutations = {\n  [_mutation_types__WEBPACK_IMPORTED_MODULE_2__[\"SAVE_TOKEN\"]](state, {\n    token,\n    remember\n  }) {\n    state.token = token;\n    js_cookie__WEBPACK_IMPORTED_MODULE_1___default.a.set('token', token, {\n      expires: remember ? 365 : null\n    });\n  },\n\n  [_mutation_types__WEBPACK_IMPORTED_MODULE_2__[\"FETCH_USER_SUCCESS\"]](state, {\n    user\n  }) {\n    state.user = user;\n  },\n\n  [_mutation_types__WEBPACK_IMPORTED_MODULE_2__[\"FETCH_USER_FAILURE\"]](state) {\n    state.token = null;\n    js_cookie__WEBPACK_IMPORTED_MODULE_1___default.a.remove('token');\n  },\n\n  [_mutation_types__WEBPACK_IMPORTED_MODULE_2__[\"LOGOUT\"]](state) {\n    state.user = null;\n    state.token = null;\n    js_cookie__WEBPACK_IMPORTED_MODULE_1___default.a.remove('token');\n  },\n\n  [_mutation_types__WEBPACK_IMPORTED_MODULE_2__[\"UPDATE_USER\"]](state, {\n    user\n  }) {\n    state.user = user;\n  }\n\n}; // actions\n\nconst actions = {\n  saveToken({\n    commit,\n    dispatch\n  }, payload) {\n    commit(_mutation_types__WEBPACK_IMPORTED_MODULE_2__[\"SAVE_TOKEN\"], payload);\n  },\n\n  async fetchUser({\n    commit\n  }) {\n    try {\n      const {\n        data\n      } = await axios__WEBPACK_IMPORTED_MODULE_0___default.a.get('/api/user');\n      commit(_mutation_types__WEBPACK_IMPORTED_MODULE_2__[\"FETCH_USER_SUCCESS\"], {\n        user: data\n      });\n    } catch (e) {\n      commit(_mutation_types__WEBPACK_IMPORTED_MODULE_2__[\"FETCH_USER_FAILURE\"]);\n    }\n  },\n\n  updateUser({\n    commit\n  }, payload) {\n    commit(_mutation_types__WEBPACK_IMPORTED_MODULE_2__[\"UPDATE_USER\"], payload);\n  },\n\n  async logout({\n    commit\n  }) {\n    try {\n      // await axios.post('/api/logout')\n      commit(_mutation_types__WEBPACK_IMPORTED_MODULE_2__[\"FETCH_USER_SUCCESS\"], {\n        user: null,\n        token: null\n      });\n    } catch (e) {}\n\n    commit(_mutation_types__WEBPACK_IMPORTED_MODULE_2__[\"LOGOUT\"]);\n  },\n\n  async fetchOauthUrl(ctx, {\n    provider\n  }) {\n    const {\n      data\n    } = await axios__WEBPACK_IMPORTED_MODULE_0___default.a.post(`/api/oauth/${provider}`);\n    return data.url;\n  }\n\n};\n\n//# sourceURL=webpack:///./resources/js/frontend/store/modules/auth.js?");

/***/ }),

/***/ "./resources/js/frontend/store/modules/lang.js":
/*!*****************************************************!*\
  !*** ./resources/js/frontend/store/modules/lang.js ***!
  \*****************************************************/
/*! exports provided: state, getters, mutations, actions */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"state\", function() { return state; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"getters\", function() { return getters; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"mutations\", function() { return mutations; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"actions\", function() { return actions; });\n/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! js-cookie */ \"./node_modules/js-cookie/src/js.cookie.js\");\n/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(js_cookie__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _mutation_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../mutation-types */ \"./resources/js/frontend/store/mutation-types.js\");\n\n\nconst {\n  locale,\n  locales\n} = window.config; // state\n\nconst state = {\n  locale: js_cookie__WEBPACK_IMPORTED_MODULE_0___default.a.get('locale') || locale,\n  locales: locales\n}; // getters\n\nconst getters = {\n  locale: state => state.locale,\n  locales: state => state.locales\n}; // mutations\n\nconst mutations = {\n  [_mutation_types__WEBPACK_IMPORTED_MODULE_1__[\"SET_LOCALE\"]](state, {\n    locale\n  }) {\n    state.locale = locale;\n  }\n\n}; // actions\n\nconst actions = {\n  setLocale({\n    commit\n  }, {\n    locale\n  }) {\n    commit(_mutation_types__WEBPACK_IMPORTED_MODULE_1__[\"SET_LOCALE\"], {\n      locale\n    });\n    js_cookie__WEBPACK_IMPORTED_MODULE_0___default.a.set('locale', locale, {\n      expires: 365\n    });\n  }\n\n};\n\n//# sourceURL=webpack:///./resources/js/frontend/store/modules/lang.js?");

/***/ }),

/***/ "./resources/js/frontend/store/modules/upload.js":
/*!*******************************************************!*\
  !*** ./resources/js/frontend/store/modules/upload.js ***!
  \*******************************************************/
/*! exports provided: state, getters, mutations, actions */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"state\", function() { return state; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"getters\", function() { return getters; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"mutations\", function() { return mutations; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"actions\", function() { return actions; });\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ \"./node_modules/axios/index.js\");\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! js-cookie */ \"./node_modules/js-cookie/src/js.cookie.js\");\n/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(js_cookie__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _mutation_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../mutation-types */ \"./resources/js/frontend/store/mutation-types.js\");\n\n\n // state\n\nconst state = {\n  code: null,\n  uploader: null\n}; // getters\n\nconst getters = {\n  code: state => state.code,\n  uploader: state => state.uploader\n}; // mutations\n\nconst mutations = {\n  [_mutation_types__WEBPACK_IMPORTED_MODULE_2__[\"CODE_SAVE\"]](state, {\n    code\n  }) {\n    state.code = code;\n  },\n\n  [_mutation_types__WEBPACK_IMPORTED_MODULE_2__[\"CODE_UPDATE\"]](state, {\n    code\n  }) {\n    state.code = code;\n  },\n\n  [_mutation_types__WEBPACK_IMPORTED_MODULE_2__[\"Uploader\"]](state, {\n    uploader\n  }) {\n    state.uploader = uploader;\n  }\n\n}; // actions\n\nconst actions = {\n  saveCode({\n    commit,\n    dispatch\n  }, payload) {\n    commit(_mutation_types__WEBPACK_IMPORTED_MODULE_2__[\"CODE_SAVE\"], payload);\n  },\n\n  updateCode({\n    commit\n  }, payload) {\n    commit(_mutation_types__WEBPACK_IMPORTED_MODULE_2__[\"CODE_UPDATE\"], payload);\n  },\n\n  setUploader: function ({\n    commit,\n    dispatch\n  }, payload) {\n    commit(_mutation_types__WEBPACK_IMPORTED_MODULE_2__[\"Uploader\"], payload);\n  }\n};\n\n//# sourceURL=webpack:///./resources/js/frontend/store/modules/upload.js?");

/***/ }),

/***/ "./resources/js/frontend/store/mutation-types.js":
/*!*******************************************************!*\
  !*** ./resources/js/frontend/store/mutation-types.js ***!
  \*******************************************************/
/*! exports provided: LOGOUT, SAVE_TOKEN, FETCH_USER, FETCH_USER_SUCCESS, FETCH_USER_FAILURE, UPDATE_USER, SET_LOCALE, CODE_SAVE, CODE_UPDATE, Uploader */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"LOGOUT\", function() { return LOGOUT; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"SAVE_TOKEN\", function() { return SAVE_TOKEN; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"FETCH_USER\", function() { return FETCH_USER; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"FETCH_USER_SUCCESS\", function() { return FETCH_USER_SUCCESS; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"FETCH_USER_FAILURE\", function() { return FETCH_USER_FAILURE; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"UPDATE_USER\", function() { return UPDATE_USER; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"SET_LOCALE\", function() { return SET_LOCALE; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"CODE_SAVE\", function() { return CODE_SAVE; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"CODE_UPDATE\", function() { return CODE_UPDATE; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"Uploader\", function() { return Uploader; });\n// auth.js\nconst LOGOUT = 'LOGOUT';\nconst SAVE_TOKEN = 'SAVE_TOKEN';\nconst FETCH_USER = 'FETCH_USER';\nconst FETCH_USER_SUCCESS = 'FETCH_USER_SUCCESS';\nconst FETCH_USER_FAILURE = 'FETCH_USER_FAILURE';\nconst UPDATE_USER = 'UPDATE_USER'; // lang.js\n\nconst SET_LOCALE = 'SET_LOCALE'; // upload.js\n\nconst CODE_SAVE = 'CODE_SAVE';\nconst CODE_UPDATE = 'CODE_UPDATE';\nconst Uploader = 'Uploader';\n\n//# sourceURL=webpack:///./resources/js/frontend/store/mutation-types.js?");

/***/ })

},[["./resources/js/frontend/main.js","runtime","vendors"]]]);