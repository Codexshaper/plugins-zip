<template>
  <div class="app-settings">
    The Settings Page
  </div>
</template>

<script>
export default {

  name: 'Settings',

  data () {
    return {

    };
  }
};
</script>

<style lang="css" scoped>
</style>
